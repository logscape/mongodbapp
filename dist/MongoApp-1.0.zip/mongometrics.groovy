
import com.mongodb.BasicDBObject;
import com.mongodb.BulkWriteOperation;
import com.mongodb.BulkWriteResult;
import com.mongodb.Cursor;
import com.mongodb.DB;
import com.mongodb.DBCollection;
import com.mongodb.DBCursor;
import com.mongodb.DBObject;
import com.mongodb.MongoClient;
import com.mongodb.ParallelScanOptions;
import java.text.SimpleDateFormat

/*

	Give the command an explicit list of deltaFields. 
		Any deltas on these fields during a softWait will printed 
		Any numerical fieds are assumed to be totals if they are included as a deltaField?t66r
		On hardWait, all fields are printed. 
*/

/*
	hosts:serverstats,listdbs:/db:dbstats,listcollections/collections:collStats
	id: {mongoHost, db , collection } 
	
	list hosts 
	list dbs 
	list colllections
	execute collStats 
		id: hosts/db/collection
		values: {} 

	the result should just be hashmap one level deep with
		* the id 
		* the results 

	execute("/hosts/dbs/collections",collStats) 

	admin/
		list:[replGetSetStatus,
		

	hosts/ i.e mongoclient 
		id: { cluster:"  " } 
		 , "list":getDatabaseNames() , "get":getDb 

		objects: {name:obj ....} 

	dbs / 
		id: { cluster: , dbs:  , 
		, "list":getCollectionNames(), "get":getCollection

		objects: { name:obj .... } 


	collections/ 
		id: { cluster, dbs:  , collections:  } 
		, "list":getIndexes() , "list.name": ,  "get":

	CacheObject 
		that may refresh these operations ? 
*/


/*

*/


class MongoCommandExecutor {
	def mongoHost=null
	def context=[:] 
	def dbObjects=[:] 
	def route=null
	def mc
	def adminDB
	def delim="\t"
	def members=null
	def MongoCommandExecutor(members,route){
		this.members=members
		this.mongoHost=members[0]  
		this.mc=new MongoClient(mongoHost) 
		this.adminDB=this.mc.getDB("admin") 
		this.route=route 

		this.context["hosts"]=this.buildExecutionContext(route) 		
	}

	def hashMapString(map){
		def kv=[]
		for(def k:map.keySet()){ 
			def v=map[k];  
			kv.add(k+":"+v) 
		} 
		return kv.join(this.delim) 
	}
	def refresh(){
		this.context["hosts"]=this.buildExecutionContext(this.route) 
	}
	def buildExecutionContext(route,parentID=null){
		if (parentID==null){
			parentID=[:] 
		}
		def uniqueID=hashMapString(parentID) 
		if (route.size() < 1) { return null;  } 
		def r =route[0] 
		if (r=="cluster"){
			def db= this.adminDB
			def context=[:] 
			def members=db.command("replSetGetStatus").members

			if (members==null) { 
				members=[] 
				this.members.each { host -> 
					members.add(["name":host]) 
				} 

			} 
			for(def member:members){
				def mongoHost=member.name 
				def id= ["cluster":this.mongoHost,"host":mongoHost] 

				context[mongoHost] =[:]
				context[mongoHost]["obj"] = new MongoClient(mongoHost) 
				context[mongoHost]["id"] =  id
				context[mongoHost]["idAsString"] =  hashMapString(id)
				this.dbObjects[hashMapString(id)]=  context[mongoHost]["obj"]

				this.dbObjects[hashMapString(["cluster":this.mongoHost,"host":mongoHost,"admindb":1])]=context[mongoHost]["obj"].getDB("admin")  

				context[mongoHost]["dbs"] = buildExecutionContext(route[1..-1],id)
				
			}
			return context 
		}
		if(r=="dbs"){
			
			if (this.dbObjects.containsKey(uniqueID) == false) {
			
				//println " Could not find object id: " + ""+uniqueID 
				//println "keys >>" + this.dbObjects.keySet() 
				return null
			}
			def obj=this.dbObjects[uniqueID]
			def context=[:] 
			for(def dbName:obj.getDatabaseNames()){
				def host=parentID["host"]
				def id=stringAsHashMap(uniqueID)
				id["db"]=dbName 
				context[dbName]=[:] 
				context[dbName]["obj"] = obj.getDB(dbName) 	

				context[dbName]["id"] = id
				context[dbName]["idAsString"] = hashMapString(id) 
				this.dbObjects[hashMapString(id)] = context[dbName]["obj"] 
				try{
					context[dbName]["collections"] = buildExecutionContext(route[1..-1],id)
				}catch(IndexOutOfBoundsException e){ 
					context[dbName]["collections"] = null
				}
			}
			
			return context 
		}


		if(r=="collections"){
			
			if (this.dbObjects.containsKey(uniqueID) == false) {
			
				println " Could not find object id: " + ""+uniqueID 
				println "keys >>" + this.dbObjects.keySet() 
				return null
			}

			def obj=this.dbObjects[uniqueID]
			def context=[:] 
			try{ 
				for(def collName:obj.getCollectionNames()){
					def host=parentID["host"]
					def id=stringAsHashMap(uniqueID)
					id["collection"]=collName 
					context[collName]=[:] 
					context[collName]["obj"] = obj.getCollection(collName) 	
					context[collName]["id"] = id
					context[collName]["idAsString"] = hashMapString(id) 
					this.dbObjects[hashMapString(id)] = context[collName]["obj"] 

					try{
						context[collName]["indexes"] = buildExecutionContext(route[1..-1],id)
					}catch(IndexOutOfBoundsException e){ 

						context[collName]["indexes"] = null
					}

				}

			}catch(com.mongodb.MongoException e){
				1;	
			}
			
			return context 
		}

		

	}
	def keyMatch(route,k){
		if (route.size()!=k.split(this.delim).size()){
			return false 

		}
		def routeB=[:]
		for(def kv:k.split(this.delim)){
			def key=kv.split(":")[0]
			def value=kv.split(":")[1]
			routeB[key]=value 
		}
		return route.sort() == routeB.keySet().sort() 
	}
	def stringAsHashMap(k){
		def map=[:] 
		for(def kv:k.split(this.delim)){
			def key=kv.split(":")[0]
			def value=kv.split(":")[1]
			map[key]=value 
		}

		return map 
	}
	def invoke(obj,methodName,args){
		obj.metaClass.methods.each { method -> 
			if(method.name==methodName){
				if (args == null){
					method.invoke(obj)
				}else{
					method.invoke(obj,args) 
				}
			}
		}
	}
	def execute(route,methodName,args=null){
		def results=[] 
		for(def k:this.dbObjects.keySet()){
			if(keyMatch(route,k)==true){
				def retValue;
				if (args!=null){
					retValue=this.dbObjects[k]."$methodName"(args)
				}else{
					
					retValue=this.dbObjects[k]."$methodName"()
				}
				results.add(retValue + stringAsHashMap(k) ) 
			}
			
		}
		return results 
	}
}


class MetricReporter{
	def prevSnapshots=[:]
	def currentSnapshots=[:] 
	def deltaMap=[:] 

	def getMapValues(){
		return this.currentSnapshots.values() 
	}
	def getDeltaMapValues() {
		return this.deltaMap.values() 
	}

	def update(executor,keyName,route,command,args=null){
		def results=executor.execute(route,command,args) 		
		for(def r:results){
			def key=r[keyName] 
			this.currentSnapshots[key]=MetricFlattenOp.go(r) 
			this.prevSnapshots[key] = this.currentSnapshots[key]
			this.deltaMap[key]=MetricDiffOp.go(this.prevSnapshots[key],this.currentSnapshots[key] ) 
 
		}
	}
}


class MetricFlattenOp {
	public static def go(map,parent=null){ 
		def fMap = [:] 
		for (def k:  map.keySet()){
			def v  = map[k]
			if(map[k] instanceof java.util.HashMap){
				fMap=fMap + go(v,parent=k) 
				continue 
			}
			if (parent != null){
				k = parent + "." + k 
			}
			fMap[k] = v 
		}

		return fMap; 
	}


}

class MetricDiffOp { 
	public static def go(map1,map2,deltaFields=[]){
		
		def diff=[:] 
		def a = null
		def b = null 
		if (map1.keySet().size() > map2.keySet().size() )  {
			a  = map1 
			b  = map2 
		}else{
			a = map2 
			b = map1 
		}
		for(def key: a.keySet() ){
			//strings 
			if (map1[key] != map2[key]){	 
				if (map1[key] instanceof String){
					diff[key]=map2[key] 
				}
				if (map1[key] instanceof Integer){
					diff[key+"Delta"]=map2[key] - map1[key]
				}


			} 
			//numbers return the delta 
			
		}
		return diff
	}
}


