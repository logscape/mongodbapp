import java.io.*;
import java.util.*;





args=["/volumes/lsdata/logscape/deployed-bundles/MongoApp-1.0/bin/m_dbstats.sh", "LookupSpaceAddress=stcp://10.28.1.160:11000", "RFSUploader=false", "ResourceAgent=stcp://10.28.1.159:11003/?svc=SHARED&host=deathstar&_startTime=25-Jul-14_11-50-46&udp=0", "ResourceAgentPort=stcp://10.28.1.159:11003/?svc=SHARED&host=deathstar&_startTime=25-Jul-14_11-50-46&udp=0", "WorkingDirectory=deployed-bundles/MongoApp-1.0", "agentPort=11003", "bundleDir=/volumes/lsdata/logscape/deployed-bundles", "bundleId=MongoApp-1.0", "bundleName=MongoApp-1.0", "consumerName=m_dbstats_wTSTAMP", "cwd=/volumes/lsdata/logscape/", "executor=java.util.concurrent.ThreadPoolExecutor@4b7a3607[Running", "pool size = 0", "active threads = 0", "queued tasks = 0", "completed tasks = 0]", "hostname=deathstar", "log=org.apache.log4j.Logger@150d1bbe", "logger=org.apache.log4j.Logger@150d1bbe", "lookupSpace=ProxyClient/-979051605 id:LookupSpace h:-979051605 fact:ProxyFactoryImpl@961867571 stcp://10.28.1.159:11003/?svc=SHARED&host=deathstar&_startTime=25-Jul-14_11-50-46&udp=0 if:LookupSpace,LifeCycle,Leasor [KeepOrderedAddresser:LookupSpace/interface com.liquidlabs.vso.lookup.LookupSpace /: list[[stcp://10.28.1.160:11000/?svc=LookupSpace&host=LAB-UK-XS-UB1&_startTime=25-Jul-14_11-52-56&udp=0]] badEP[] replay?:false reason:] STARTED LastUsed:25-Jul-14 11:52:08,669 LastSync:25-Jul-14 11:52:14,817 LastRefresh:", "lookupSpaceAddress=stcp://10.28.1.160:11000", "lookupUrl=stcp://10.28.1.160:11000", "master=172.17.0.4", "osArch=amd64", "osName=LINUX", "port=27017", "profileId=0", "proxyFactory=ProxyFactoryImpl@961867571 stcp://10.28.1.159:11003/?svc=SHARED&host=deathstar&_startTime=25-Jul-14_11-50-46&udp=0", "resourceAgent=stcp://10.28.1.159:11003/?svc=SHARED&host=deathstar&_startTime=25-Jul-14_11-50-46&udp=0", "resourceId=deathstar-11003-0", "scheduler=java.util.concurrent.ScheduledThreadPoolExecutor@f9861be[Running", "pool size = 0", "active threads = 0", "queued tasks = 0", "completed tasks = 0]", "serviceManager=com.liquidlabs.vso.agent.EmbeddedServiceManager@5f8fb5c:Fri Jul 25 11:52:39 BST 2014 deathstar-11003-0:MongoApp-1.0:m_dbstats_wTSTAMP lifeCycle:[] NullFuture", "serviceName=m_dbstats_wTSTAMP", "thisAgent=com.liquidlabs.vso.agent.ResourceAgentImpl@5d3908f1", "workAllocation=-1", "workId=deathstar-11003-0:MongoApp-1.0:m_dbstats_wTSTAMP", "zone=lab.saas"]

def process  = new ProcessBuilder(args).redirectErrorStream(true).start() 
process.inputStream.eachLine { println it} 


