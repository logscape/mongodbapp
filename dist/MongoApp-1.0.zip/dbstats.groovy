import com.mongodb.BasicDBObject;
import com.mongodb.BulkWriteOperation;
import com.mongodb.BulkWriteResult;
import com.mongodb.Cursor;
import com.mongodb.DB;
import com.mongodb.DBCollection;
import com.mongodb.DBCursor;
import com.mongodb.DBObject;
import com.mongodb.MongoClient;
import com.mongodb.ParallelScanOptions;
import java.text.SimpleDateFormat


pout = pout == null ? System.out : pout
perr = perr == null ? System.err : perr

def stdOut = pout
def stdErr = perr
Logger logger = new Logger()
logger.setOutStream(pout)
logger.setErrStream(perr)


def propertyMissing(String name) {}
def arguments  =  args  as List 

def properties= null;


if (arguments!=null) {
	properties=new ExecutionContext(arguments) 
}else{
	properties=new ExecutionContext(arguments,_bindings) 
} 

members=properties.map["members"].split(",") 

softWait=15 // Checks every 20 seconds for a change. If there is it will print it
hardWait=60 // Prints Eveny minute regardless of change. 
hardWaitCount=60
waitTotal=0
metricStore=null



def mce = new MongoCommandExecutor(members ,["cluster","dbs","collections"]) 
def reporter= new MetricReporter() 



key="db" 

while(hardWaitCount > 0){


	reporter.update(mce,key,["cluster","host","db"],"getStats",null ) 
	
	if (waitTotal % hardWait == 0 ){
		for(def r:reporter.getMapValues() ){   logger.logkv(r) }
		mce.refresh() 
		hardWaitCount-- 
	}else{
		for(def r:reporter.getDeltaMapValues() ){ logger.logkv(r) }
	}
	
	
	Thread.sleep(softWait*1000)
	waitTotal+=softWait

}



System.exit(0) 



class Logger{
	private static verbose=false;
	private static Logger instance = null;
	private static pout;
	private static perr;
	private Logger(){}

	def setVerboseTrue(){
		verbose=true;
	}
	
	def getInstance(){
		if(instance==null){
			instance = new Logger();
		}
		return instance;
	}
	def setOutStream(def out){
		pout=out		
	}
	def setErrStream(def err){
		perr=err
	} 
	def log( line ){
		def dt = new Date()
		SimpleDateFormat dateFormatter = new SimpleDateFormat("dd-MMM-yyyy HH:mm:ss zzz"); 
		//def timestamp = String.format('%1$te-%1$tb-%1$ty %tT',dt) 
		def timestamp=dateFormatter.format(dt)
		pout <<  "" + timestamp + "\t" + line  + "\n" 
	}

	def logkv( map ) {
		def line=""
		if (map.keySet().size() < 1) { return } 
		for(def k: map.keySet()){
			def v = map[k] 
			line=line +  ', "' + k + '": "' + v  +'"'
		}
		log(line) 
	}
	def error( line ,exception=null) { 
		def dt = new Date()
		def timestamp = String.format('%1$te-%1$tb-%1$ty %tT',dt) 
		perr <<  "" + timestamp + "\t" + line  + "\n" 
	}

	def exception(line,exception=null){
		this.error("Exception: ["+line+"]") 

		if(exception!=null){
			exception.printStackTrace(perr) 
		}
	}
	def verbose(line){
		if(verbose){
			error(line);
		}
	}
}
