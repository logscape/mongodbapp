members=[] ; rs.conf().members.forEach(function(el) { members.push(el.host) } ) ; members
