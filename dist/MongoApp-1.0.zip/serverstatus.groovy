import com.mongodb.BasicDBObject;
import com.mongodb.BulkWriteOperation;
import com.mongodb.BulkWriteResult;
import com.mongodb.Cursor;
import com.mongodb.DB;
import com.mongodb.DBCollection;
import com.mongodb.DBCursor;
import com.mongodb.DBObject;
import com.mongodb.MongoClient;
import com.mongodb.ParallelScanOptions;
import java.text.SimpleDateFormat


pout = pout == null ? System.out : pout
perr = perr == null ? System.err : perr

def stdOut = pout
def stdErr = perr
Logger logger = new Logger()
logger.setOutStream(pout)
logger.setErrStream(perr)


def propertyMissing(String name) {}
def properties=[:]
 
def settings =  Settings.newInstance()
def arguments  =  args  as List 
bindings=settings.getBindingFromArguments(arguments) 

if (bindings.containsKey("devMode") == true){
	println "javaapp:: devmode:: init"
	properties=bindings 
}else{
	properties=_bindings 
}


cmd="serverStatus" 
master=properties["master"]
port=properties["port"]
 
mongoHost=master+":"+port

softWait=2 // Checks every 20 seconds for a change. If there is it will print it
hardWait=60 // Prints Eveny minute regardless of change. 
hardWaitCount=60
waitTotal=0
metricStore=null
/*

	Give the command an explicit list of deltaFields. 
		Any deltas on these fields during a softWait will printed 
		Any numerical fieds are assumed to be totals if they are included as a deltaField?t66r
		On hardWait, all fields are printed. 
*/
def mc = new MongoClient(mongoHost);
def db = mc.getDB("admin")

def reporters=[]
for(def member:db.command("replSetGetStatus").members){
	def mongoHost=member.name 
	reporters.add(new MetricReporter(mongoHost,cmd)) 

}
/*reporters[0].update() 
println reporters[0].getDeltaMap() 
println reporters[0].getMap() 
*/

class MetricReporter{
	def mongoHost=null
	def mongoClient=null
	def mongoCommand=null
	def adminDb=null
	def prevSnapshot=[:]
	def currSnapshot=[:] 
	def deltaMap=[:]
	def MetricReporter(mongoHost,cmd){
		this.mongoHost=mongoHost
		this.mongoCommand =cmd 
		this.mongoClient = new MongoClient(mongoHost);
		this.adminDb  = this.mongoClient.getDB("admin")
	}
	def update(){
		this.prevSnapshot=this.currSnapshot
		this.currSnapshot=MetricFlattenOp.go(this.adminDb.command(this.mongoCommand))
		this.deltaMap=MetricDiffOp.go(this.prevSnapshot,this.currSnapshot) 
		this.deltaMap["mongoHost"]=this.mongoHost 
		this.currSnapshot["mongoHost"] = this.mongoHost 
	}
	def getDeltaMap(){ return this.deltaMap }
	def getMap() { return this.currSnapshot} 

}

while(hardWaitCount > 0){

	for(def r: reporters){
		r.update() 
	}
	Thread.sleep(softWait*1000)

	waitTotal+=softWait
	if (waitTotal % hardWait == 0 ){
		for(def r:reporters){ logger.logkv(r.getMap()) }
	}else{
		for(def r:reporters){ logger.logkv(r.getDeltaMap()) }
	}
	
	
	hardWaitCount-- 
}


class MetricFlattenOp {
	public static def go(map,parent=null){ 
		def fMap = [:] 
		for (def k:  map.keySet()){
			def v  = map[k]
			if(map[k] instanceof java.util.HashMap){
				fMap=fMap + go(v,parent=k) 
				continue 
			}
			if (parent != null){
				k = parent + "." + k 
			}
			fMap[k] = v 
		}

		return fMap; 
	}


}

class MetricDiffOp { 
	public static def go(map1,map2,deltaFields=[]){
		
		def diff=[:] 
		def a = null
		def b = null 
		if (map1.keySet().size() > map2.keySet().size() )  {
			a  = map1 
			b  = map2 
		}else{
			a = map2 
			b = map1 
		}
		for(def key: a.keySet() ){
			//strings 
			if (map1[key] != map2[key]){	 
				if (map1[key] instanceof String){
					diff[key]=map2[key] 
				}
				if (map1[key] instanceof Integer){
					diff[key+"Delta"]=map2[key] - map1[key]
				}


			} 
			//numbers return the delta 
			
		}
		return diff
	}
}


class Logger{
	private static verbose=false;
	private static Logger instance = null;
	private static pout;
	private static perr;
	private Logger(){}

	def setVerboseTrue(){
		verbose=true;
	}
	
	def getInstance(){
		if(instance==null){
			instance = new Logger();
		}
		return instance;
	}
	def setOutStream(def out){
		pout=out		
	}
	def setErrStream(def err){
		perr=err
	} 
	def log( line ){
		def dt = new Date()
		SimpleDateFormat dateFormatter = new SimpleDateFormat("dd-MMM-yyyy HH:mm:ss zzz"); 
		//def timestamp = String.format('%1$te-%1$tb-%1$ty %tT',dt) 
		def timestamp=dateFormatter.format(dt)
		pout <<  "" + timestamp + "\t" + line  + "\n" 
	}

	def logkv( map ) {
		def line=""
		for(def k: map.keySet()){
			def v = map[k] 
			line=line +  ', "' + k + '": "' + v  +'"'
		}
		log(line) 
	}
	def error( line ,exception=null) { 
		def dt = new Date()
		def timestamp = String.format('%1$te-%1$tb-%1$ty %tT',dt) 
		perr <<  "" + timestamp + "\t" + line  + "\n" 
	}

	def exception(line,exception=null){
		this.error("Exception: ["+line+"]") 

		if(exception!=null){
			exception.printStackTrace(perr) 
		}
	}
	def verbose(line){
		if(verbose){
			error(line);
		}
	}
}
